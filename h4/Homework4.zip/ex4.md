# ex4.sh

This `c` file applies semapores. The program can print count of numbers and check its correctness.