# h6ex4

This file causes system with 3 GiB memory thrashing.

Usage:

```
gcc -o h6ex4 h6ex4.c
```

