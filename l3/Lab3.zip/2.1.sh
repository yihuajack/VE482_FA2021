pkgin install rsync
man rsync
cp -r /usr/src/ /usr/src_orig
rsync -avz minix:/usr/src /mnt/f/Resources